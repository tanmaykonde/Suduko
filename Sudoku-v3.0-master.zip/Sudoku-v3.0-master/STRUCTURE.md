## FILE STRUCTURE OF PROJECT <br />
<br />
C:.<br />
│   build.xml<br />
│   manifest.mf<br />
│<br />
├───nbproject<br />
│   │   build-impl.xml<br />
│   │   genfiles.properties<br />
│   │   project.properties<br />
│   │   project.xml<br />
│   │<br />
│   └───private<br />
│           private.properties<br />
│           private.xml<br />
│<br />
├───src<br />
│       DisplayPanel.java<br />
│       MySudoku.java<br />
│       SButton.java<br />
│       Smethods.java<br />
│       SPanel.java<br />
│<br />
└───test<br />
